


<!-- End: PHP-Session-Code -->


<!DOCTYPE html>
<html>

	<head>
    <meta 
			charset="utf-8">
    <meta 
			name="viewport" 
			content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Clear Title and Appraisal CO. make-a-payment</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css">
    <link rel="stylesheet" href="assets/css/smoothproducts.css">
		<link rel=	"stylesheet" href=	"assets/css/Bold-BS4-Text-Shadow-Effects.css"/>
		<link rel=	"stylesheet" href=	"https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.css"/>
    <meta 
			name="keywords" 
			content="Clear Title and Appraisal CO.,  Zoning,  Wire Note,  Wire Authorization,  Will,  Warranty,  VuWriter,  Vesting Deed,  Vestee,  Vest,  Vendors Lien,  Vendor,  Vendee,  Variable Rate Mortgage,  VA Guarantee,  Unrecorded Instrument,  Unmarketable Title,  Unity of Title,  Unincorporated,  Underwriter,  TX,  Twitter,  Trustee,  Trust,  Tract,  Township,  Torrens Title,  Tools,  Title,  Title Search,  Title Premium,  Title Plant,  Title Insurance,  Title Defect,  Title Company,  Texas,  Texas Underwriting,  Texas Society of Professional Land Surveyors,  Texas District Courts,  Texas Board of Professional Land Surveyors,  Testatrix,  Testator,  Testate,  Testament,  Tenant,  Tenancy in Common,  Tenancy by the Entirety,  Tax year,  Tax Search,  Tax Lien,  Tax ID Number,  Tax Exemption,  Survey Review and Approval,  Survey Name,  Substitute Trustee,  Subdivision,  Street name,  Street City State Zip,  Stewart Title Guaranty Company,  State License ID,  Signing Fee,  Shortages in Area,  Short Term Loan,  Short Legal,  Seven Reasons for Title Insurance,  Settlement Type,  Settlement Date,  Settlement Agent,  Settlement,  Set Back Lines,  Selling Price,  Selling Home,  Selling Agent Commission,  Section of Land,  Second Mortgage,  Schedule D,  Schedule A, B, C and D of the Title Commitment,  Sanctions Search,  Sales Price,  Sales Price minus Loan Amount,  Runsheet,  Routing Number,  Right of Way,  Richardson,  ResWare,  Restrictions,  RESPA,  Request for Reconveyance,  REO,  Remote Access,  Remittance,  Release,  REIT,  Reinstatement,  Refinancing,  Refinancing,  Recording Instrument,  Recording Fee,  Recording Documents,  Recording Deed,  Recorded Electronically,  Recordation,  Reconveyance,  Recital,  Receivables,  Realtors Net Sheet,  Real Estate Title,  Real Estate Settlement Procedures Act,  Real Estate Owned,  Real Estate Investment Trusts,  Real Estate Board,  Real estate appraiser,  Range,  Range Unplatted,  Quitclaim Deed,  Public Report,  Public Records,  Provision in a mortgage,  Property Value,  Property Tax,  Property Section,  Property Run,  Proof of ownership,  Profit,  Probates,  Pro Rate,  Privity,  Private Mortgage Insurance,  Prescriptive Easement,  Premiums,  Power of Attorney,  Policy Easements and Restrictions,  Plated Easements,  Plated Building Setback Lines,  Plat Records,  Plano,  Piggyback Policy,  Peroration,  Payoff Amount,  Payment Total,  Pay Online,  Paul Bertanzetti  Parcel,  Parcel Map,  Pacer,  Owner and Buyer,  Outstanding Liens,  Open House,  Online Payments,  On the job training,  Oil Wells,  Oil and Gas,  Offer,  Obligor,  Oblige,  Notice of Default,  Notice of Completion,  Notice of Action,  Notary Public,  Notarize,  North Dallas,  North American Title Insurance Company,  Non Judicial Foreclosure Sale,  Non Exclusive Listing,  New Loans,  Net Valuation,  Negative Cash Flow,  Nationwide Coverage,  National Rate Calculator,  National Association of Realtors,  NATIC,   NAR,  Name and Address,  Mutual Water Company,  Mortgagor,  Mortgagee,  Mortgage Security Instrument,  Mortgage Rates,  Mortgage Company,  Mortgage Beneficiary,  Mortgage Bander,  Monument,  Miteck,  Minority,  Mineral Rights,  Mineral Exception,  Metes and Bounds,  Member Appraisal Institute,  Mechanics Lien,  McKinney,  Marketable Title,  Market Value,  Marital Status,  Management Fee,  Make a Payment,  Maintenance Fee,  MAI,  Lot and Block,  Los Payable Clause,  Looking for a new career,  Loan Type,  Loan Policy,  Loan Number,  Loan Amount,  Lis pen dens,  Link,  Life Estate,  Lien,  Lessor,  Lessee,  Lenders Policy,  Lender easements and restrictions,  Legal,  Legal Description,  Lease,  Landmark,  Land Value,  Land Contract,  Judgment Lien,  Judgement,  Judgement Docket,  Joint Tenancy,  Jerry Bell,  Intestate,  Interim Financing,  Insurance,  Insurance Loan,  Instagram,  Ingress,  Indemnify,  Inchoate Dower,  Inchoate Curtesy,  Improvements,  Improvement Value,  Immanent domain,  I need to,  HUD Line Amount,  Housing and Urban Development,  Homestead Affidavit,  Homeland Security Watch List,  Home Repair Loan,  Home Equity Loan,  Home Equity Conversion Mortgage,  HOA,  Hiatus,  Help,  Guardian,  Grantor,  Grantee,  Graduated Payment Mortgage,  Governmental Agency,  Government National Mortgage Association,  Google Maps,   Google Earth,  GNMA,  Ginnie Mae,  GF,  Get your certification,  Gas Pipeline,  Frisco,  Free advice,  Foreclosure,  Foreclosure of Mortgages,  FNMA,  Flood Plain Map Research,  Flood Certification,  Financing,  Finance Charge,  File Public Records,  Fidelity,  FHA,  Federal Statute,  Federal National Mortgage Association,  Federal Housing Administration,  Fannie Mae,  Family,  Facebook,  Extended Mortgage,  Explanation of Texas Endorsements,  Executor,  Examination of Title,  Estate,  Escrow,  Escheat,  Equity Amount,  Endorsement Policy Number,  Endorsement Line,  Encumbrance,  Encumber,  Egress,  Easements and Restrictions,  Earnest Money,  Due on Sale Clause,  DT,  Drainage Easements,  Divorces,  Disbursement Date,  DFW,  Devise,  Delivery,  Defective Title,  Deed of Trust,  Deed of Record,  Deed Chain,  Decree,  Debtors,  DataTrace,  Data Trace System,  Dallas County Records,  Dallas Appraisal,  Cul-De-Sac,  Covenants,  Covenant,  Courthouse Direct,  County Clerk,  Corp of Engineers,  Contract for sale,  Contract for Deed,  Continuing Education,  Conservator,  Conservancy Assessment,  Condominium Declaration,  Conditions,  Common Interest Community CIC,  Commitment,  Commitments,  Colling Appraisal,  Collin County Records,  Closing,  Closing Office,  Closing Date,  Closing Costs,  Clients file number,  Clear Title,  Chain of Title,  Certified,  Cash Out Amount,  By-Laws,  Buying a new house,  Broker Real Estate,  Brian Reddy,  Borrower,  Boot,  Blanket Mortgage,  Beneficiary,  Beneficial Estate,  Base Map,  Bankruptcy Search,  Bank Account Number,  Balloon Payment,  Balloon Note,  Backup offer,  Background Check,  Attorney,  Assessors Vesting,  Arbitration Clause,  Arbitrary Map,  Appurtenance,  Appropriation,  Appraiser,  Appraised Value,  Appraisal,  Appraisal Services,  Appraisal Fees,  Appraisal Facts,  Appraisal Company,  Appel Loan,  Annexation,  Amortize,  Amortization,  American Institute of Real Estate Appraisers,  American Bankers Association,  Amendment,  ALTA/ACSM Land Title Surveys,  ALTA Best Practices,  Allen,  Affordable,  Affirmative Easement  Affidavit,  Adverse Possession,  Administrator,  Adjustable Mortgage Loans,  Adjudication,  Adam Bell,  Action to Quiet Title,  Acrobat Reader,  Acknowledgement  Accommodation Recording,  Access Right,  Acceleration Clause,  Accelerating Payoff Progressive Equity Loan,  Abstracts of Judgement,  ABA Number,  clear2close.us,  8775700505,  75080,  75013,  465 W President George Bush,  2147829860,  1778 W McDermott Dr">
    <meta 
			name="description" 
			content="Clear Title and Appraisal CO. is your solution for Appraisal and Title services NATIONWIDE! You can order Appraisal Reports and Title searches anywhere in the United States with just the click of a button. Our team is dedicated to providing quality Appraisal and Title products through advanced technology and unmatched customer service. Place your orders today and see the difference! We are committed to helping your property transaction go as smoothly as possible. We handle all of the details so you don’t have to. We might be based in the Dallas-Fort Worth area, but like I said, we use technology to facilitate property sales transactions nationwide. If you have already chosen a Closing Agent, do not hesitate to make use of our free reference data to help you understand what it is your about to get yourself into. Both Buyers and Sellers have their roles to play in this sometimes confusing transaction and we constantly do our best to take the burden off of you and simplify the process.  Our company's philosophy is to provide an objective analysis to assist our clients in making informed real estate decisions. At Clear Title and Appraisal CO., we pride ourselves in delivering exceptional customer service. We believe our products and technology are unique and that allows us to deliver the best service to our clients be they the Buyers, Sellers or the Agents running the show. We make everyone shine. My name is Adam Bell and I am the proud owner of Clear Title and Appraisal CO.. Please feel free to contact me personally. I have assembled a team that always gives it their all. Feedback is a gift, both good and bad. I share your input with my team. The numerous comments of praise allows me to keep them fired up, encouraged to deliver great service. The not so good is equally important. It helps keep us humble, never settling for a status quo, and keeps us headed in the right direction. You can call be directly at 877-570-0505 Ext 111 or by sending me a note at adam.bell@clear2close.us">
    <meta 
			name="twitter:image" 
			content="BJR Green Letters logo.png">
    <meta 
			property="og:image" 
			content="BJR Green Letters logo.png">
    <meta 
			property="og:type" 
			content="website">
    <link rel="icon" type="image/jpeg" sizes="220x202" href="assets/img/Transparent%20CLR.jpg">
    <link rel="icon" type="image/jpeg" sizes="220x202" href="assets/img/Transparent%20CLR.jpg">
    <link rel="icon" type="image/jpeg" sizes="220x202" href="assets/img/Transparent%20CLR.jpg">
    <link rel="icon" type="image/jpeg" sizes="220x202" href="assets/img/Transparent%20CLR.jpg">
    <link rel="icon" type="image/jpeg" sizes="220x202" href="assets/img/Transparent%20CLR.jpg">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
    <link rel="stylesheet" href="assets/css/CLRTAG.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">
	</head>

	<body class="d-flex flex-column justify-content-center justify-content-sm-center justify-content-md-center justify-content-lg-center" style="background-color: rgb(246,246,246);">
    	
	<nav class="navbar navbar-light navbar-expand-md fixed-top bg-white d-flex flex-grow-1 flex-shrink-1" id="CLR-MainMenu">
        <div class="container-fluid">
					<a class="navbar-brand d-flex align-items-center">
						<img data-aos="zoom-in" data-aos-duration="950" data-aos-delay="950" data-aos-once="true" src="https://clear2closeus.wpengine.com/wp-content/uploads/2022/08/logo.png" height="90%" width="auto">
					</a>
					<button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-2">
						<span>
						</span>
						<span class="navbar-toggler-icon">
						</span>
					</button>
					<div class="collapse navbar-collapse" id="navcol-2">
						<ul class="nav navbar-nav d-flex flex-grow-1 flex-shrink-1 justify-content-around align-items-center align-content-center" style="width: 100%;min-width: 100%;max-width: 100%;background-color: #000;">
							<li class="nav-item" role="presentation" id="home-item">
								<a class="nav-link" id="CLRWebPageLink-1" href="/">
									HOME
								</a>
							</li>
							<li class="nav-item" role="presentation" id="information-item">
								<a class="nav-link" id="InfoLink-1" href="https://clear2close.us/title-escrow/">
									Title & Escrow
								</a>
							</li>
							<li class="nav-item" role="presentation" id="about-us-item">
								<a class="nav-link" id="AboutUsLink-1" href="https://clear2close.us/appraisal/">
									Appraisal
								</a>
							</li>
							<li class="nav-item" role="presentation" id="education">
								<a class="nav-link" id="NetSheetLink-1" href="https://clear2close.us/continuing-education/">
									Education
								</a>
							</li>
							<li class="nav-item" role="presentation" id="net-sheet-item">
								<a class="nav-link" id="NetSheetLink-1" href="https://clear2close.us/net-sheet/">
									Net Sheet
								</a>
							</li>
							<li class="nav-item" role="presentation" id="contact-us">
								<a class="nav-link" id="NetSheetLink-1" href="https://clear2close.us/contact-us/">
									Contact Us
								</a>
							</li>
						</ul>
					</div>
        </div>
    </nav>
    <main class="page login-page" style="margin-top: 15vh;background-color: rgb(246,246,246);">
			<section class="clean-block clean-form dark">
				<div class="container">
						<form 
							id="formLogin" 
							action="/payment/make-a-payment.php"
							method="post"
							accept-charset="utf-8"
							style="border-top: 5px solid #000000;"
						>
							<div class="form-group" id="email-username">
								<label class="d-flex justify-content-center" id="email-usernameLabel" for="email">
									File ID
								</label>
								<input class="form-control" type="text" "id="email" name="username" />
							</div>
							<div class="form-group" id="zip-password">
								<label class="d-flex justify-content-center" id="zip-passwordLabel" for="pwd">
									Password
								</label>
								<input class="form-control" type="password" id="pwd" name="password" href="#" />
							</div>
							<button class="btn btn-primary btn-block" id="LogInButton" type="submit" name="submit">
								Log In
							</button>
						</form>
				</div>
			</section>
		</main>
	

	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/js/smart-forms.min.js"></script>
	<script src="assets/js/bs-init.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
	<script src="assets/js/smoothproducts.min.js"></script>
	<script src="assets/js/theme.js"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.js"></script>
	<!-- Start: jQueryFunction -->
	<script type="text/javascript">
		jQuery(function()
			{
			$('#formLogin').submit(function(e)
				{
				// alert('Unable to connect to API using this IP');
				// return false;
				// e.preventDefault();
				});
			});
	</script>
</body>

</html>